package com.java.class18;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;

public class JListEx extends JFrame{
    public JListEx() {
        setTitle("JList 예제");
        setSize(160, 300);

// 리스트에 들어가는 내용에 따라서 panel의 사이즈를 조정하고 싶다면
// panel을 사용해야 한다.
        JPanel c = new JPanel();
        c.setLayout(new FlowLayout());
        c.setSize(160, 200);
        add(c);

// 컴포넌트 생성
// 1 배열을 이용하여 JList 생성
//JList<String> strList = new JList<>(new String[]{"안녕", "자바", "JList 샘플", "중이야"}) ;
//c.add(strList); //JScrollPane을 달고 싶다면 해당 라인은 주석처리한다. 그게 아니라면 주석을 지운다.

// 2.Vector을 이용하여 JList 생성
        Vector<String> vector = new Vector<>();
        vector.add("안녕");
        vector.add("자바");
        vector.add("안녕2");
        vector.add("안녕3");
        JList<String> strList = new JList<>(vector);

// listModel은 read only 객체임
        ListModel<String> listModel = strList.getModel();
        System.out.println(listModel.getElementAt(1));

// JList에 스크롤을 달고 싶다면? 둘중 아무거나 해도 됨
        JScrollPane scrollPane = new JScrollPane(strList);
// 수평 스크롤을 잠그고 싶을 때
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
//JScrollPane scrollPane = new JScrollPane();
//scrollPane.getViewport().setView(strList);
        c.add(scrollPane);
//strList.add(new JTextField("이후 추가해봄"));

        JTextField textField = new JTextField(10);
        JButton button = new JButton("추가하기");
        c.add(textField);
        c.add(button);

// 이벤트 또한 스레드 스케쥴러를 통해서 관리되고 있다.
        button.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                SwingUtilities.invokeLater( new Runnable() {
                    @Override
                    public void run() {
// 아무래도 vector에 추가한다고 해서 JList가 리프레쉬가 되는 것이 아니기에
// JList를 update 하여 UI에 반영해줘야 한다.
                        vector.add( textField.getText() );
                        if(strList.getFixedCellWidth() < textField.getText().length()*10 ) {
                            strList.setFixedCellWidth( textField.getText().length() * 10 );
                        }
                        strList.updateUI();
//c.setSize( c.getSize().width*10, c.getSize().height);
                        scrollPane.updateUI();
//글자수에 따른 컨테이너 사이즈 변경
                        c.updateUI();
                    }
                });

            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }


    public static void main(String[] args) {
        new JListEx();
    }
}